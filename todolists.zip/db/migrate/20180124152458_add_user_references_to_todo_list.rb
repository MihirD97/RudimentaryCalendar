class AddUserReferencesToTodoList < ActiveRecord::Migration
  def change
  	
  end
end
